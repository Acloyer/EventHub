﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventHub.Data;
using EventHub.Models;
using Microsoft.Extensions.Logging;

namespace EventHub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class RoleController : ControllerBase
    {
        private readonly EventHubDbContext _db;
        private readonly ILogger<RoleController> _logger;

        public RoleController(EventHubDbContext db, ILogger<RoleController> logger)
        {
            _db = db;
            _logger = logger;
        }

        // ── GET api/role ────────────────────────────────────────────────
        // Только Admin и Moderator могут получить весь список ролей
        [HttpGet]
        [Authorize(Roles = "Admin,Moderator")]
        public async Task<IActionResult> GetAllRoles()
            => Ok(await _db.Roles.Select(r => r.Name).ToListAsync());

        // ── GET api/role/user/{userId} ──────────────────────────────────
        // Admin и Organizer могут смотреть, какие роли у конкретного юзера
        [HttpGet("user/{userId}")]
        [Authorize(Roles = "Admin,Organizer")]
        public async Task<IActionResult> GetUserRoles(int userId)
        {
            var roles = await _db.UserRoles
                .Include(ur => ur.Role)
                .Where(ur => ur.UserId == userId && ur.Role != null)
                .Select(ur => ur.Role!.Name)
                .ToListAsync();
            return Ok(roles);
        }

        public class RoleAssignDto
        {
            public int UserId { get; set; }
            public string Role { get; set; } = null!;
        }

        // ── POST api/role/assign ────────────────────────────────────────
        // Только Admin может выдать роль
        [HttpPost("assign")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AssignRole(int userId, int roleId)
        {
            var user = await _db.Users.FindAsync(userId);
            if (user == null)
                return NotFound("User not found");

            var role = await _db.Roles.FindAsync(roleId);
            if (role == null)
                return NotFound("Role not found");

            var userRole = new UserRole
            {
                UserId = userId,
                User = user,
                RoleId = roleId,
                Role = role
            };

            _db.UserRoles.Add(userRole);
            await _db.SaveChangesAsync();

            return Ok();
        }

        // ── POST api/role/remove ───────────────────────────────────────
        // Только Admin может снять роль
        [HttpPost("remove")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveRole([FromBody] RoleAssignDto dto)
        {
            var ur = await _db.UserRoles
                .Include(x => x.Role)
                .SingleOrDefaultAsync(ur => ur.UserId == dto.UserId && ur.Role != null && ur.Role.Name == dto.Role);

            if (ur == null) return NotFound("Role assignment not found");

            _db.UserRoles.Remove(ur);
            await _db.SaveChangesAsync();
            return Ok();
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Role>>> GetRoles()
        {
            var roles = await _db.Roles
                .Include(r => r.UserRoles)
                .ToListAsync();

            return roles.Select(r => new Role 
            { 
                Id = r.Id, 
                Name = r.Name,
                UserRoles = r.UserRoles ?? new List<UserRole>()
            }).ToList();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Role>> GetRole(int id)
        {
            var role = await _db.Roles
                .Include(r => r.UserRoles)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (role == null)
            {
                return NotFound(new { message = "Role not found" });
            }

            return new Role 
            { 
                Id = role.Id, 
                Name = role.Name,
                UserRoles = role.UserRoles ?? new List<UserRole>()
            };
        }

        [HttpPost]
        public async Task<ActionResult<Role>> CreateRole(Role role)
        {
            if (await _db.Roles.AnyAsync(r => r.Name == role.Name))
            {
                return BadRequest(new { message = "Role already exists" });
            }

            _db.Roles.Add(role);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetRole), new { id = role.Id }, role);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRole(int id)
        {
            var role = await _db.Roles.FindAsync(id);
            if (role == null)
            {
                return NotFound(new { message = "Role not found" });
            }

            _db.Roles.Remove(role);
            await _db.SaveChangesAsync();

            return NoContent();
        }
    }
}
