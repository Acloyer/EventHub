﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using EventHub.Data;
using EventHub.Services;
using System.Security.Cryptography;
using Telegram.Bot;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add CORS policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:3000")
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });
});

// Configure Telegram Bot
var botToken = builder.Configuration.GetSection("TelegramBot:Token").Value;
builder.Services.AddSingleton<ITelegramBotClient>(new TelegramBotClient(botToken ?? throw new InvalidOperationException("Telegram bot token not configured")));

// Add services to the container.
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
        options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull;
    });
builder.Services.AddEndpointsApiExplorer();

// Configure Swagger with JWT authentication
builder.Services.AddSwaggerGen(c =>
{
    c.CustomSchemaIds(type => type.FullName);
    
    // Добавляем информацию о безопасности для Swagger
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// Add DbContext for application data
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
// Add DbContext for event hub controllers
builder.Services.AddDbContext<EventHubDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// Configure JWT Authentication
var jwtSection = builder.Configuration.GetSection("Jwt");
var key = Encoding.ASCII.GetBytes(jwtSection["Secret"] ?? throw new InvalidOperationException("JWT secret not configured"));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.SaveToken = true;
    options.RequireHttpsMetadata = false;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSection["Issuer"],
        ValidAudience = jwtSection["Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ClockSkew = TimeSpan.Zero
    };
    
    // Добавляем обработку событий для отладки
    options.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            Console.WriteLine("OnAuthenticationFailed: " + context.Exception.Message);
            return Task.CompletedTask;
        },
        OnTokenValidated = context =>
        {
            Console.WriteLine("OnTokenValidated: " + context.SecurityToken);
            return Task.CompletedTask;
        },
        OnChallenge = context =>
        {
            Console.WriteLine("OnChallenge: " + context.Error);
            return Task.CompletedTask;
        }
    };
});

builder.Services.AddAuthorization();

// Add other services
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddHostedService<NotificationHostedService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "EventHub API V1");
        // Добавляем поддержку JWT токена в Swagger UI
        c.DefaultModelsExpandDepth(-1); // Скрываем схемы моделей по умолчанию
        c.DocExpansion(Swashbuckle.AspNetCore.SwaggerUI.DocExpansion.None); // Сворачиваем все методы по умолчанию
    });
}

// Use CORS before auth and endpoints
app.UseCors("AllowFrontend");

app.UseHttpsRedirection();

// Add authentication before authorization
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Initialize database
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    context.Database.Migrate();

    // Проверяем и создаем роли
    var requiredRoles = new[] { "Admin", "User", "Organizer" };
    foreach (var roleName in requiredRoles)
    {
        if (!context.Roles.Any(r => r.Name == roleName))
        {
            context.Roles.Add(new EventHub.Models.Role 
            { 
                Name = roleName,
                UserRoles = new List<EventHub.Models.UserRole>() 
            });
        }
    }
    context.SaveChanges();

    // Create test users if they don't exist
    var testUsers = new[]
    {
        new { Email = "123@mail.ru", Password = "123", Role = "Admin" },
        new { Email = "12@mail.ru", Password = "12", Role = "Organizer" }
    };

    foreach (var testUser in testUsers)
    {
        var user = context.Users
            .Include(u => u.UserRoles)
            .FirstOrDefault(u => u.Email == testUser.Email);

        if (user == null)
        {
            using var hmac = new HMACSHA512();
            user = new EventHub.Models.User
            {
                Email = testUser.Email,
                PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(testUser.Password)),
                PasswordSalt = hmac.Key,
                UserRoles = new List<EventHub.Models.UserRole>()
            };
            context.Users.Add(user);
            context.SaveChanges();
        }

        // Получаем роль из базы
        var role = context.Roles.FirstOrDefault(r => r.Name == testUser.Role);
        if (role == null)
        {
            throw new Exception($"Role {testUser.Role} not found in database!");
        }

        // Проверяем, нет ли уже такой роли у пользователя
        if (!user.UserRoles.Any(ur => ur.RoleId == role.Id))
        {
            var userRole = new EventHub.Models.UserRole
            {
                UserId = user.Id,
                User = user,
                RoleId = role.Id,
                Role = role
            };
            user.UserRoles.Add(userRole);
            context.UserRoles.Add(userRole);
            context.SaveChanges();
        }
    }

    // Remove default admin if exists
    var defaultAdmin = context.Users.FirstOrDefault(u => u.Email == "admin@eventhub.com");
    if (defaultAdmin != null)
    {
        var adminRoles = context.UserRoles.Where(ur => ur.UserId == defaultAdmin.Id);
        context.UserRoles.RemoveRange(adminRoles);
        context.Users.Remove(defaultAdmin);
        context.SaveChanges();
    }
}

app.Run();
